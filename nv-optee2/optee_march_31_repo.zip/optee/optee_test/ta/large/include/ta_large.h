/* SPDX-License-Identifier: BSD-2-Clause */
/*
 * Copyright (c) 2021, Linaro Limited
 */

#ifndef TA_LARGE_H
#define TA_LARGE_H

#define TA_LARGE_UUID { 0x25497083, 0xa58a, 0x4fc5, \
	{ 0x8a, 0x72, 0x1a, 0xd7, 0xb6, 0x9b, 0x85, 0x62 } }

#endif /*TA_LARGE_H */
