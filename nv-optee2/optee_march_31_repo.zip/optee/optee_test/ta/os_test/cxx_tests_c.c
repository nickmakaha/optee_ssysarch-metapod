// SPDX-License-Identifier: BSD-2-Clause
/*
 * Copyright (c) 2020 Huawei Technologies Co., Ltd
 */

#include "cxx_tests.h"

void throwing_c_func(void)
{
	throw_mfe();
}
