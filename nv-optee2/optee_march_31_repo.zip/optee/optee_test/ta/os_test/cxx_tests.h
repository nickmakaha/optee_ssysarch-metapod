/* SPDX-License-Identifier: BSD-2-Clause */
/*
 * Copyright (c) 2020 Huawei Technologies Co., Ltd
 */

#ifndef CXX_TESTS_H
#define CXX_TESTS_H

void throw_mfe(void);
void throwing_c_func(void);

#endif /* CXX_TESTS_H */
