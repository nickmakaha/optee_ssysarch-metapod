/* SPDX-License-Identifier: BSD-2-Clause */
/*
 * Copyright (c) 2022, Linaro Limited
 */

#ifndef TA_SUBKEY1_H
#define TA_SUBKEY1_H

#define TA_SUBKEY1_UUID { 0x5c206987, 0x16a3, 0x59cc, \
	{ 0xab, 0x0f, 0x64, 0xb9, 0xcf, 0xc9, 0xe7, 0x58 } }

#endif /*TA_SUBKEY1_H */
