/* SPDX-License-Identifier: BSD-2-Clause */
/*
 * Copyright (c) 2021, Linaro Limited
 */

#ifndef TA_SUBKEY2_H
#define TA_SUBKEY2_H

#define TA_SUBKEY2_UUID { 0xa720ccbb, 0x51da, 0x417d, \
	{ 0xb8, 0x2e, 0xe5, 0x44, 0x5d, 0x47, 0x4a, 0x7a } }

#endif /*TA_SUBKEY2_H */
