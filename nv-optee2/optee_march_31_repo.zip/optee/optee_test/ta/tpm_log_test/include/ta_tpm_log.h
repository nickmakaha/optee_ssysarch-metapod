/* SPDX-License-Identifier: BSD-3-Clause */
/*
 * Copyright (c) 2020, ARM Limited. All rights reserved.
 */

#ifndef TA_TPM_LOG_H
#define TA_TPM_LOG_H

#include <ta_tpm_log_test.h>
#include <tee_api.h>

#endif /* TA_TPM_LOG_H */
