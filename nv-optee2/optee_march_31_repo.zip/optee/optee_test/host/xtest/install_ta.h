/*
 * Copyright (c) 2017, Linaro Limited
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */

#ifndef INSTALL_TA_H
#define INSTALL_TA_H

int install_ta_runner_cmd_parser(int argc, char *argv[]);

#endif /*INSTALL_TA_H*/
