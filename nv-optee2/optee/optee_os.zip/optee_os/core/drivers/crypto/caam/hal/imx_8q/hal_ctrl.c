// SPDX-License-Identifier: BSD-2-Clause
/*
 * Copyright 2020-2021 NXP
 */
#include <caam_hal_ctrl.h>
#include <compiler.h>

void caam_hal_ctrl_init(vaddr_t baseaddr __unused)
{
}
